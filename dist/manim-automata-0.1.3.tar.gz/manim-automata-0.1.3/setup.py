# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['manim_automata',
 'manim_automata.mobjects',
 'manim_automata.mobjects.automata_dependencies']

package_data = \
{'': ['*']}

install_requires = \
['xmltodict>=0.13.0,<0.14.0']

entry_points = \
{'manim.plugins': ['manim_automata = module:object.attr']}

setup_kwargs = {
    'name': 'manim-automata',
    'version': '0.1.3',
    'description': '',
    'long_description': None,
    'author': 'Sean Nelson',
    'author_email': 'snelson01010@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
