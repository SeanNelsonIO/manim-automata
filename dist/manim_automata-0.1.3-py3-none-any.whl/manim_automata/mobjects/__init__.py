from .automaton_mobject import *
__all__ = ["ManimAutomaton"]
